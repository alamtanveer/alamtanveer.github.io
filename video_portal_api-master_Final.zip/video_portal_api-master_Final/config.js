var configs = {};
configs.applicationPort = 3000;
configs.dbName = 'CrossoverVideosAssignment';
configs.dbHost = 'localhost';

module.exports = configs;