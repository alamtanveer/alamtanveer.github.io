mainApp.controller('mainController', function ($rootScope, $scope, restService, $location) {
    var vm = $scope;    
    $scope.isCheck=true;
    $scope.isList=false;

    //$scope.sid=$rootScope.videoList; 
    vm.login=function(){
        var data = {"username":"ali", "password":"5f4dcc3b5aa765d61d8327deb882cf99"}
        restService.authentication(data).then(function(resp){
            if(resp.data.status=="success"){                
                sessionStorage.setItem('sessionId',resp.data.sessionId) 
                $rootScope.userD=vm.username;
                $location.path("/main");
                vm.getVideoData(resp.data.sessionId)
            }
            else{
                $('.try-again').text(resp.data.error)
            }           
        })            
    };
    vm.getVideoData=function(param){        
        restService.videoListing(param).then(function(resp){            
            $rootScope.videoList=resp.data.data;            
            //console.log($scope.videoList)            
            for (var i = 0; i < $rootScope.videoList.length; i++) {
                var index=$rootScope.videoList[i].ratings[$rootScope.videoList[i].ratings.length-1];
                //console.log($('#'+$scope.videoList[i]._id))
            }
         
        })
    };  
    vm.getUrl=function(get){
        $rootScope.setUrl=get;
        $scope.isCheck=false;
        $scope.isList=true;
    };
    $scope.logout=function(){
         restService.logoutAPI(sessionStorage.getItem('sessionId')).then(function(resp){
            if(resp.data.status=="success"){                
                       $location.path("/");
                       sessionStorage.removeItem('sessionId')                  
            }
            else{
                
            }           
        })          
    };

    $(document).scroll(function (event) {
        restService.scrollVideo(sessionStorage.getItem('sessionId'), 1).then(function(resp){
             if(resp.data.status=="success"){
                var scroll=$(document).scrollTop();
                if(window.innerHeight >=scroll) { 
                        $rootScope.videoList.push(resp.data.data[0])
                    /*for(var i=0; i<resp.data.data.length; i++){
                    }*/
                }
            }
        })
      });
    setTimeout(function(){
        $('.rating input').change(function () {
                  var $radio = $(this);
                  var videoId=$(this).parents('li').find('video').attr('id');
                  var rating=$(this).attr('value');

                  var data={"videoId":videoId,"rating":rating};
                  restService.ratings(data).then(function(resp){
                    //console.log(resp.data.data)
                  })
                  var id=$(this).parents().siblings("video").attr('id');
                  $("#"+id+" ~ .rating .selected").removeClass('selected');                                
                  $radio.closest('label').addClass('selected');                 
                  $("#"+id+" ~ .rating .apply").removeClass('apply')
                  $radio.addClass('apply');
                });         
                  
    },2000)
         
   
})