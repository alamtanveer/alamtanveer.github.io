mainApp.directive('viddeoz',function($rootScope, $window, $timeout){
    return{
        restrict:'AE',
        templateUrl:"../app/template/videoListing.html",
        link:function(scope,element,attr){
           console.log("hello"); 
        }
    }
})