mainApp.factory('restService',function($http, $q){    

    var API = {
        login : "/user/auth",
        videoList:"/videos",
        logout:"user/logout",
        rating:"video/ratings"
    }    
    return{
        authentication:function(data){            
            return $http.post(API.login, data);
        },
        videoListing:function(data){
            console.log(data);
            return $http.get(API.videoList+"?sessionId="+data);
        },
        logoutAPI:function(data){
            return $http.get(API.logout+"?sessionId="+data);
        },
        scrollVideo:function(param1,param2){
            return $http.get(API.videoList+"?sessionId="+param1+"&limit"+param2);
        },
        ratings:function(data){            
            return $http.post(API.rating+"?sessionId="+sessionStorage.getItem('sessionId'),data);
        }
    }
})