var mainApp = angular.module("crossOver", ['ngRoute','ngAnimate','ngSanitize']); 

mainApp.config(['$routeProvider', function ($routeProvider) {
    $routeProvider.
    when("/", {
        templateUrl: '../app/template/login.html'
        , controller: 'mainController'
    }).
    when("/main", {
        templateUrl: './app/template/videoListing.html'
        , controller: 'mainController'
    }).
    when("/mainvideo", {
        templateUrl: './app/template/mainVideo.html'
        , controller: 'mainController'
    }).
    otherwise({
        redirectTo: '/'

    });
         }]);

