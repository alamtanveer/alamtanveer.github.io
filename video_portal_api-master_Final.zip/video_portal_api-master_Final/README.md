# Crossover Video Portal backend
This is the backend API code that needs to be consumed by front-end applications.
